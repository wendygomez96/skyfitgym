<?php

$host = 'localhost';
$user = 'root';
$clave = '';
$db = 'proyecto';

$conexion=mysqli_connect($host, $user,$clave,$db)

?>
