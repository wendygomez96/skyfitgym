<?php require_once('cabecera.php'); ?>
<body>
    <header>
        <img src="imagenesprueba/logo1.png" title="SKY FIT GYM" id="logoinicio" class="auto-style9" />
        <a href="https://es-la.facebook.com/" target="_blank"><img class="auto-style10" src="imagenesprueba/facebook.png" /></a>
        <a href="https://www.instagram.com/?hl=es-la" target="_blank"><img class="auto-style11" src="imagenesprueba/instagram2.png" /></a>
        <h1 id="h1" class="auto-style1">&nbsp;<span class="auto-style4"><strong><span class="auto-style8">SKY FIT GYM</span></strong></span></h1>
        &nbsp;<h3 id="tprincipal2" class="auto-style1"> <span class="auto-style7">TU SALUD TU MEJOR INVERSION...</span> </h3>
        &nbsp;
    </header>
        <form id="form1" runat="server">
          <div class="auto-style6">
          <div class="auto-style2">

              &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
              &nbsp;&nbsp;<strong><a href="/proyecto2/index.php" CssClass="auto-style3">Inicio</a>
              </strong>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
              &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;<strong><a href="/proyecto2/nosotros.php" CssClass="auto-style3">Nosotros</a>
              </strong>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
              &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;<strong><a href="/proyecto2/contactenos.php" CssClass="auto-style3">Contactenos</a>
              </strong>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
              &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <strong>
              <a href="/proyecto2/login2.php" CssClass="auto-style3">Inicie Sesion</a>
            </strong>
        </div><br /><br />
        <div class="auto-style18">

            <ul class="slider">
                <li id="slide1">
                    <img src="imagenesprueba/slider1.jpg"/>
                </li>
                <li id="slide2">
                    <img src="imagenesprueba/slider2.webp"/>
                </li>
                <li id="slide3">
                    <img src="imagenesprueba/skyinicio.png"/>
                </li>
                <li id="slide4">
                    <img src="imagenesprueba/slider4.jpg"/>
                </li>
           </ul>

          <ul class="menu">
                <li>
                    <a href="#slide1">1</a>
                </li>
                <li>
                    <a href="#slide2">2</a>
                </li>
                <li>
                    <a href="#slide3">3</a>
                </li>
                <li>
                    <a href="#slide4">4</a>
                </li>
        </ul>

    </div>

    <p class="auto-style5">
            SKY FIT GYM ofrece servicios de maquinas, fitness, aerobic, spining, entre otros,
            para todo tipo de publico, desde jóvenes, mediana edad, y personas mayores, adaptándonos a cada
            nivel, por que tu salud es la mejor inversión...
       </p>
        <iframe class="videoinicio" width="560" height="315" src="https://www.youtube.com/embed/nY8bjJr7Ew0?start=6" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen=""></iframe>
        </div>
    </form>
    <footer class="auto-style12">
        <b>Copyright<br/>
        Autor: GAES 5 <br />
        Fecha de actualización: 20 Junio 2021</b>
    </footer>
</body>
</html>
