<?php

header("content-type: text/css; charset: UTF-8")

 ?>

 html {
     background-image: url('imagenesprueba/fondo1.jpg');
 }

 h1 {
     font-size: 400%;
     padding: 0%;
 }

 #h1 {
     margin-top: 2%;
 }

 header {
     margin: 1%;
 }

 .auto-style1 {
     text-align: right;
     margin: 0%;
     padding: 0%;
 }

 .auto-style2 {
     background: linear-gradient(to top, red, orange, yellow);
     padding: 0.5%;
     text-align: center;
     font-size: 15pt;
 }
 .auto-style2 a:visited {
     color: black;
     text-decoration: none;
 }
 .auto-style2 a:active {
     color: black;
     text-decoration: none;
 }
 .auto-style2 a:link {
     color: black;
     text-decoration: none;
 }
 .auto-style2 a:hover {
     color: red;
 }

 .auto-style3 {
     text-decoration-line: none;
     color: black;
 }

 .auto-style4 {
     font-weight: normal;
     font-size: larger;
 }

 .auto-style7 {
     font-size: x-large;
     background-color: #FFCC00;
 }

 .auto-style8 {
     background: linear-gradient(to top, red, orange, yellow);
 }

 .auto-style9 {
     float: left;
     width: 23%;
     height: 136px;
 }

 .auto-style10 {
     height: auto;
     width: 4%;
     text-align: center;
     float: left;
     left: 349px;
     top: 43px;
     margin-left: 170px;
     margin-top: 50px;
     margin-bottom: 3px;
 }

 .auto-style11 {
     height: auto;
     width: 3.5%;
     text-align: center;
     float: left;
     left: 349px;
     top: 43px;
     margin-left: 65px;
     margin-top: 55px;
     margin-bottom: 3px;
 }

 .auto-style12 {
     margin: 2%;
     background: linear-gradient(to top, red, orange, yellow);
     text-align: center;
 }

 .slogan {
     padding-top: -2%;
 }
