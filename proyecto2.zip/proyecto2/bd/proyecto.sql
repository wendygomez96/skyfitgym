-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 20-09-2021 a las 21:42:13
-- Versión del servidor: 10.4.20-MariaDB
-- Versión de PHP: 7.4.21

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `proyecto`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `agregarcompra`
--

CREATE TABLE `agregarcompra` (
  `codigo` varchar(30) NOT NULL,
  `producto` varchar(30) NOT NULL,
  `cantidad` varchar(30) NOT NULL,
  `proveedor` varchar(30) NOT NULL,
  `costounidad` varchar(30) NOT NULL,
  `preciodeventa` varchar(30) NOT NULL,
  `fecha` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `agregarcompra`
--

INSERT INTO `agregarcompra` (`codigo`, `producto`, `cantidad`, `proveedor`, `costounidad`, `preciodeventa`, `fecha`) VALUES
('2', 'Vitamina B', '46', 'Proveedor de prueba 2', '1364', '8000', '2021-09-01'),
('3', 'Vitamina C', '66', 'Proveedor de prueba 3', '16300', '31700', '2021-09-06'),
('4', 'Vitamina D', '72', 'Proveedor de prueba 4', '3900', '12000', '2021-09-04'),
('8', 'Vitamina Prueba', '43', 'prueba', '2350', '11000', '2021-09-11'),
('8', 'Vitamina Prueba', '43', 'prueba', '2350', '6000', '2021-09-05'),
('9', 'vitamina t', '37', 'prueba', '2350', '11800', '2021-09-02'),
('2', 'Vitamina B pureba', '56', 'prueba', '2345', '11000', '2021-09-10'),
('2', 'Vitamina B pureba', '47', 'prueba', '3100', '12650', '2021-09-12'),
('2', 'Vitamina B pureba', '47', 'prueba', '3100', '12650', '2021-09-12'),
('2', 'Vitamina B pureba', '47', 'prueba', '3100', '12650', '2021-09-12'),
('2', 'Vitamina B pureba', '47', 'prueba', '3100', '12650', '2021-09-12'),
('2', 'Vitamina B pureba', '47', 'prueba', '3100', '12650', '2021-09-12'),
('2', 'Vitamina B pureba', '47', 'prueba', '3100', '12650', '2021-09-12'),
('2', 'Vitamina B pureba', '47', 'prueba', '3100', '12650', '2021-09-12'),
('2', 'Vitamina B pureba', '47', 'prueba', '3100', '12650', '2021-09-12'),
('2', 'Vitamina B pureba', '47', 'prueba', '3100', '12650', '2021-09-12'),
('2', 'Vitamina B pureba', '47', 'prueba', '3100', '12650', '2021-09-12'),
('41', 'vitamina c', '43', 'prueba', '2350', '11000', '2021-09-14'),
('2', 'Vitamina B pureba', '47', 'prueba', '3100', '12650', '2021-09-09'),
('2', 'Vitamina B pureba', '47', 'prueba', '3100', '12650', '2021-09-13');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `agregarequipos`
--

CREATE TABLE `agregarequipos` (
  `codigo` varchar(30) NOT NULL,
  `equipo` varchar(30) NOT NULL,
  `unidades` varchar(30) NOT NULL,
  `proveedor` varchar(30) NOT NULL,
  `costounidad` varchar(30) NOT NULL,
  `fecha` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `agregarequipos`
--

INSERT INTO `agregarequipos` (`codigo`, `equipo`, `unidades`, `proveedor`, `costounidad`, `fecha`) VALUES
('M1', 'caminadora', '23', 'Proveedor de prueba 1', '1250000', '2021-09-01'),
('7', 'bicicleta', '59', 'prueba', '1200000', '2021-09-12'),
('4', 'caminadora', '78', 'prueba', '2550', '2021-09-06');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `borrarcompra`
--

CREATE TABLE `borrarcompra` (
  `codigo` varchar(30) NOT NULL,
  `producto` varchar(30) NOT NULL,
  `cantidad` varchar(30) NOT NULL,
  `proveedor` varchar(30) NOT NULL,
  `costounidad` varchar(30) NOT NULL,
  `preciodeventa` varchar(30) NOT NULL,
  `fecha` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `borrarequipos`
--

CREATE TABLE `borrarequipos` (
  `codigo` varchar(30) NOT NULL,
  `equipo` varchar(30) NOT NULL,
  `unidades` varchar(30) NOT NULL,
  `proveedor` varchar(30) NOT NULL,
  `costounidad` varchar(30) NOT NULL,
  `fecha` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `contactenos`
--

CREATE TABLE `contactenos` (
  `identificacion` varchar(30) NOT NULL,
  `nombres` varchar(30) NOT NULL,
  `apellidos` varchar(30) NOT NULL,
  `correo` varchar(30) NOT NULL,
  `telefono` varchar(15) NOT NULL,
  `empresa` varchar(30) NOT NULL,
  `ciudad` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `contactenos`
--

INSERT INTO `contactenos` (`identificacion`, `nombres`, `apellidos`, `correo`, `telefono`, `empresa`, `ciudad`) VALUES
('1016091567', 'Wendy Alexandra', 'Gomez Bocanegra', 'wen@gmail.com', '3135678903', 'cocotec', 'Bogota'),
('101655677091356', 'wendy', 'gomez', 'wen@email.com', '33456433', 'cocotec', 'Bucaramanga'),
('123332787', 'Alexandra', 'prueba', 'wen@gmail.com', '33456433', 'cocotec', 'medellin'),
('123442', 'wendy', 'Gomez Bocanegra', 'wen@gmail.com', '33456433', 'cocotec', 'medellin'),
('123450876', 'Alexandra', 'prueba', 'hola', 'sdsfggh', 'cocotec', 'medellin'),
('12345566', 'Alexandra', 'Gomez Bocanegra', 'wen@gmail.com', '33456433', 'cocotec', 'BOGOTa'),
('123552', 'wendy', 'gomez', 'WENDY@GMAIL.COM', '345532', 'cocotec', 'BOGOTA'),
('1235522', 'Alexandra', 'gomez', 'wen@email.com', '33456433', 'FELIZ', 'BOGOTa'),
('12355324545', 'Katherine', 'Castellanos', 'kathe@email.com', '33456433', 'Telep', 'medellin'),
('12355345354', 'wendy', 'prueba', 'dvgdhdd', '33456433', 'cocotec', 'BOGOTa'),
('123553677', 'pepito', 'prueba', 'hola@email.com', '33456433', 'cocotec', 'Bogota'),
('1235537643', 'wendy', 'Gomez Bocanegra', 'wendygomez961207@gmail.com', '33456433', 'cocotec', 'Bucaramanga'),
('12355566767', 'Wendy Alexandra', 'prueba', 'wen@gmail.com', '33456433', 'cocotec', 'Bogota'),
('1235556787', 'wendy', 'gomez', 'wen@email.com', '', '', 'BOGOTa'),
('1235556787233', 'wendy', 'prueba', 'wen@gmail.com', '33456433', 'cocotec', 'medellin'),
('12355567872332344', 'wendy', 'prueba', 'wen@gmail.com', '33456433', 'cocotec', 'medellin'),
('12366543', 'prueba', 'prueba', 'prueba', 'nj', 'k', 'bbjj'),
('1359584', 'wendy', 'prueba', 'wen@email.com', '3456664', 'cocotec', 'cali'),
('14563', 'Alexandra', 'Gomez', 'wen@gmail.com', '33456433', 'FELIZ', 'Cali'),
('23344', 'wendy', 'gomez', 'wen@gmail.com', '33456433', 'cocotec', 'Bogota'),
('65432267889', 'wendy', 'prueba', 'wen@gmail.com', '33456433', 'prueba 3', 'Cali'),
('feliz', 'feliz', 'gomez', 'wen@email.com', '33456433', 'FELIZ', 'cali');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `inventarioequipos`
--

CREATE TABLE `inventarioequipos` (
  `codigo` varchar(30) NOT NULL,
  `equipo` varchar(30) NOT NULL,
  `proveedor` varchar(30) NOT NULL,
  `costo` varchar(30) NOT NULL,
  `mantenimiento` date NOT NULL,
  `stock` varchar(30) NOT NULL,
  `imagen` varchar(800) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `inventarioequipos`
--

INSERT INTO `inventarioequipos` (`codigo`, `equipo`, `proveedor`, `costo`, `mantenimiento`, `stock`, `imagen`) VALUES
('4', 'caminadora', 'prueba', '2550', '2021-09-06', '78', ''),
('7', 'bicicleta', 'prueba', '1200000', '2021-09-12', '59', ''),
('M2', 'Bicicleta prueba', 'Proveedor de prueba 4', '6700000', '0000-00-00', '12', '.'),
('M3', 'Bicicleta estatica', 'prueba', '1200000', '2021-09-14', '59', ''),
('M4', 'Computador', 'Proveedor de prueba 2', '2250000', '2021-09-09', '7', ''),
('M5', 'caminadora', 'Proveedor de prueba 1', '6700000', '2021-09-03', '5', ''),
('m7', 'bicicleta', '34566', '4500', '2021-09-05', '78', '');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `inventarioproductos`
--

CREATE TABLE `inventarioproductos` (
  `codigo` varchar(30) NOT NULL,
  `producto` varchar(30) NOT NULL,
  `proveedor` varchar(30) NOT NULL,
  `costo` varchar(30) NOT NULL,
  `preciodeventa` varchar(30) NOT NULL,
  `stock` varchar(30) NOT NULL,
  `imagen` varchar(400) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `inventarioproductos`
--

INSERT INTO `inventarioproductos` (`codigo`, `producto`, `proveedor`, `costo`, `preciodeventa`, `stock`, `imagen`) VALUES
('14', 'Producto de prueba', 'prueba', '2350', '11000', '37', NULL),
('2', 'Vitamina B pureba', 'prueba', '3100', '12650', '47', 'Vitamina B.jpg'),
('41', 'vitamina c', 'prueba', '2350', '11000', '43', NULL),
('6', 'Vitamina C', 'Proveedor de prueba 3', '5400', '12000', '35', 'Vitamina C.jpg'),
('9', 'vitamina t', 'prueba', '2350', '11800', '37', NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `proveedores`
--

CREATE TABLE `proveedores` (
  `nit` varchar(30) NOT NULL,
  `empresa` varchar(30) NOT NULL,
  `direccion` varchar(30) NOT NULL,
  `ciudad` varchar(30) NOT NULL,
  `telefono` varchar(30) NOT NULL,
  `email` varchar(30) NOT NULL,
  `producto` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `proveedores`
--

INSERT INTO `proveedores` (`nit`, `empresa`, `direccion`, `ciudad`, `telefono`, `email`, `producto`) VALUES
('134654322-9', 'prueba', 'carrera 86c #17-36', 'Medellin', '34553253', 'prueba@mail.com', 'Vitamina Z'),
('5443211-4', 'Prueba 2', 'carrera 13c #17-65', 'Bucaramanga', '543222', 'prueba2@mail.com', 'Vitamina C'),
('657832-7', 'Prueba 6', 'carrera 76c #45-67', 'Santander', '56789', 'prueba3@mail.com', ''),
('657832-75', 'cocotec', 'Carrera 56#58-20', 'medellin', '33456433', 'wendygomez971207@gmail.com', 'vitamina c');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `registro`
--

CREATE TABLE `registro` (
  `identificacion` varchar(30) NOT NULL,
  `nombres` varchar(30) NOT NULL,
  `apellidos` varchar(30) NOT NULL,
  `correo` varchar(30) NOT NULL,
  `contrasena` varchar(30) NOT NULL,
  `confirmecontrasena` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `registro`
--

INSERT INTO `registro` (`identificacion`, `nombres`, `apellidos`, `correo`, `contrasena`, `confirmecontrasena`) VALUES
('1016091356', 'Wendy Alexandra', 'Gomez Bocanegra', 'wendygomez961207@gmail.com', 'pepito', 'pepito'),
('123456', 'admin', 'admin', 'admin@mail.com', '123456', '123456'),
('343647', 'prueba1', 'xgthth', 'hyht', 'thrfth', 'dhfth'),
('56784', '56784', 'prueba', 'prueba@email.com', '98453', '98453'),
('98767', 'usuario', 'usuario', 'usuario@email.com', 'sistema', 'sistema');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `rutinasclientes`
--

CREATE TABLE `rutinasclientes` (
  `identificacion` varchar(30) NOT NULL,
  `nombres` varchar(30) NOT NULL,
  `apellidos` varchar(30) NOT NULL,
  `instructor` varchar(30) NOT NULL,
  `actividad` varchar(30) NOT NULL,
  `fecha` date NOT NULL,
  `horainicio` time NOT NULL,
  `horafinal` time NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `rutinasplanes`
--

CREATE TABLE `rutinasplanes` (
  `identificacion` varchar(30) NOT NULL,
  `nombres` varchar(30) NOT NULL,
  `apellidos` varchar(30) NOT NULL,
  `plan` varchar(30) NOT NULL,
  `costoplan` varchar(30) NOT NULL,
  `fechainicio` date NOT NULL,
  `fechafinal` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `rutinasplanes`
--

INSERT INTO `rutinasplanes` (`identificacion`, `nombres`, `apellidos`, `plan`, `costoplan`, `fechainicio`, `fechafinal`) VALUES
('123552', 'prueba septiembre', 'prueba', 'Seleccione', '50000', '2021-09-01', '2021-09-01'),
('1235556787', 'prueba agregar', 'prueba', 'Oro', '100000', '2021-08-26', '2021-09-26');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `rutinasprogramadas`
--

CREATE TABLE `rutinasprogramadas` (
  `identificacion` varchar(30) NOT NULL,
  `nombres` varchar(30) NOT NULL,
  `apellidos` varchar(30) NOT NULL,
  `instructor` varchar(30) NOT NULL,
  `actividad` varchar(50) NOT NULL,
  `fecha` date NOT NULL,
  `horainicio` time NOT NULL,
  `horafinal` time NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `rutinasprogramadas`
--

INSERT INTO `rutinasprogramadas` (`identificacion`, `nombres`, `apellidos`, `instructor`, `actividad`, `fecha`, `horainicio`, `horafinal`) VALUES
('1016091356', 'Wendy Alexandra', 'Gomez Bocanegra', 'Libre', 'PRUEBA', '2021-09-30', '13:43:00', '15:43:00'),
('1016091356', 'Wendy Alexandra', 'Gomez Bocanegra', 'Libre', 'Caminadora', '2021-09-27', '13:50:00', '14:50:00');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `contactenos`
--
ALTER TABLE `contactenos`
  ADD PRIMARY KEY (`identificacion`);

--
-- Indices de la tabla `inventarioequipos`
--
ALTER TABLE `inventarioequipos`
  ADD PRIMARY KEY (`codigo`);

--
-- Indices de la tabla `inventarioproductos`
--
ALTER TABLE `inventarioproductos`
  ADD PRIMARY KEY (`codigo`);

--
-- Indices de la tabla `proveedores`
--
ALTER TABLE `proveedores`
  ADD PRIMARY KEY (`nit`);

--
-- Indices de la tabla `registro`
--
ALTER TABLE `registro`
  ADD PRIMARY KEY (`identificacion`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
